SYNOPSIS
	switch solve --verbose --log-run



To read results in Terminal type:

ipython
import pickle
test_pickle = pickle.load(open("./outputs/results.pickle","rb"))
print(test_pickle)



Here is a test change.
